import { api } from './api';

type LoginPayload = { username: string; password: string };
type LoginResponse = { access: string; refresh?: string };

export async function login(payload: LoginPayload) {
  const candidates = [
    '/token/',        // FastAPI comum (com barra final)
    '/token',         // FastAPI/DRF sem barra
    '/auth/token/',   // variação com prefixo
    '/auth/token',
    '/api/token/',    // outra variação comum
    '/api/token',
  ];

  let lastError: unknown;

  for (const path of candidates) {
    try {
      const { data } = await api.post<LoginResponse>(path, payload);
      return data;
    } catch (err: any) {
      // Se 404, tenta próximo candidato; se outro erro, propaga direto
      if (err?.response?.status !== 404) {
        throw err;
      }
      lastError = err;
    }
  }

  // Se chegou aqui, deu 404 em todas
  throw lastError ?? new Error('Nenhuma rota de token encontrada (404). Verifique VITE_API_URL e endpoints.');
}
