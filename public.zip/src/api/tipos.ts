import { api } from './api';
import type { Tipo } from '../types';

export async function listarTiposAtivos() {
  const { data } = await api.get<Tipo[]>('/tipos/ativos/');
  return data;
}

export async function listarTiposInativos() {
  const { data } = await api.get<Tipo[]>('/tipos/inativos/');
  return data;
}

export async function criarTipo(payload: { nome: string }) {
  const form = new URLSearchParams();
  form.append('nome', payload.nome);

  const { data } = await api.post<Tipo>('/tipo/', form, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  return data;
}

export async function alternarStatusTipo(id: number) {
  const { data } = await api.put(`/tipo/${id}/status/`);
  return data;
}
