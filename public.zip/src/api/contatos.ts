import { api } from './api';
import type { Contato } from '../types';

export async function listarContatosAtivos() {
  const { data } = await api.get<Contato[]>('/contatos/ativos/');
  return data;
}

export async function listarContatosInativos() {
  const { data } = await api.get<Contato[]>('/contatos/inativos/');
  return data;
}

export async function criarContato(payload: { nome: string; tipo_id: number }) {
  const form = new URLSearchParams();
  form.append('nome', payload.nome);
  form.append('tipo_id', String(payload.tipo_id));

  const { data } = await api.post<Contato>('/contato/', form, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  return data;
}

export async function alternarStatusContato(id: number) {
  const { data } = await api.put(`/contato/${id}/status/`);
  return data;
}
