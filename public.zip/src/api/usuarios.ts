import { api } from './api';
import type { Usuario } from '../types';

export async function listarUsuariosAtivos() {
  const { data } = await api.get<Usuario[]>('/usuarios/ativos/');
  return data;
}

export async function listarUsuariosInativos() {
  const { data } = await api.get<Usuario[]>('/usuarios/inativos/');
  return data;
}

export async function criarUsuario(payload: { nome: string; email: string }) {
  const form = new URLSearchParams();
  form.append('nome', payload.nome);
  form.append('email', payload.email);

  const { data } = await api.post<Usuario>('/usuario/', form, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  return data;
}

export async function alternarStatusUsuario(id: number) {
  const { data } = await api.put(`/usuario/${id}/status/`);
  return data;
}
