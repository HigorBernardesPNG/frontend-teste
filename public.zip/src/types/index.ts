export type Usuario = { id: number; nome: string; email: string; ativo: boolean };
export type Tipo = { id: number; nome: string; ativo: boolean };
export type Contato = { id: number; nome: string; tipo_id: number; ativo: boolean };
