import { isAxiosError } from 'axios';

type ApiErrorShape = {
  detail?: string;
  message?: string;
  error?: string;
  // outros campos que a API possa retornar…
};

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null;
}

export function getHttpErrorMessage(e: unknown): string {
  if (isAxiosError(e)) {
    const data = e.response?.data;
    if (isRecord(data)) {
      const d = data as ApiErrorShape;
      return d.detail ?? d.message ?? d.error ?? e.message;
    }
    return e.message;
  }
  if (e instanceof Error) return e.message;
  return 'Algo deu errado.';
}
